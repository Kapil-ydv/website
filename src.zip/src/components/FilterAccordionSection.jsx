import React from "react";

const CHEVRON_SVG = (
  <svg
    width={16}
    height={16}
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M13.5306 6.53073L8.5306 11.5307C8.46092 11.6007 8.37813 11.6561 8.28696 11.694C8.1958 11.7318 8.09806 11.7513 7.99935 11.7513C7.90064 11.7513 7.8029 11.7318 7.71173 11.694C7.62057 11.6561 7.53778 11.6007 7.4681 11.5307L2.4681 6.53073C2.3272 6.38984 2.24805 6.19874 2.24805 5.99948C2.24805 5.80023 2.3272 5.60913 2.4681 5.46823C2.60899 5.32734 2.80009 5.24818 2.99935 5.24818C3.19861 5.24818 3.3897 5.32734 3.5306 5.46823L7.99997 9.93761L12.4693 5.46761C12.6102 5.32671 12.8013 5.24756 13.0006 5.24756C13.1999 5.24756 13.391 5.32671 13.5318 5.46761C13.6727 5.60851 13.7519 5.7996 13.7519 5.99886C13.7519 6.19812 13.6727 6.38921 13.5318 6.53011L13.5306 6.53073Z"
      fill="currentColor"
    />
  </svg>
);

function FilterAccordionSection({ isOpen, onToggle, title, dataIndex, children }) {
  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onToggle();
    }
  };

  return (
    <div
      className={`m-filter--widget m-accordion--item ${isOpen ? "open" : ""}`}
      data-index={dataIndex}
    >
      <div
        className="m-filter--widget-title h5 m-accordion--item-button"
        onClick={onToggle}
        onKeyDown={handleKeyDown}
        role="button"
        tabIndex={0}
        aria-expanded={isOpen}
      >
        <span>{title}</span>
        <span className="m-accordion--item-icon">{CHEVRON_SVG}</span>
      </div>
      <div
        className="m-filter--widget-content m-accordion--item-content"
        style={{ opacity: isOpen ? 1 : 0 }}
      >
        {children}
      </div>
    </div>
  );
}

export default FilterAccordionSection;
